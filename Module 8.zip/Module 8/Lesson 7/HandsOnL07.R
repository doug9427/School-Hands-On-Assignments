library("rcompanion")
library("car")
library("effects")
library("multcomp")

## Data Wrangling
cellPhone$International.Plan = as.factor(cellPhone$International.Plan)
cellPhnoe$vMail.Plan = as.factor(cellPhone$vMail.Plan)

## Testing Assumptions
plotNormalHistogram(cellPhone$Night.Mins)
# Looks normally distributed

## Homogeneity of variance
leveneTest(Night.Mins~International.Plan, data=cellPhone)
# Not significant, so passed the test

## Homogeneity of Regression Slope
Homogeneity_RegrSlp = lm(Night.Mins~vMail.Plan, data=cellPhone)
anova(Homogeneity_RegrSlp)
# This assumption has been met as well, the p-value is > .05.

## Analysis
ANCOVA = lm(Night.Mins~vMail.Plan + International.Plan*vMail.Plan, data=cellPhone)
anova(ANCOVA)
# There is no influence on night time minutes regardless of the international plan status, and holding for the status of the voice mail plan as well.