library('gmodels')
library('dplyr')
library('tidyr')

# Part 1: Does the term of the loan influence loan status?
CrossTable(loans$term, loans$loan_status, fisher=TRUE, chisq=TRUE, expected=TRUE, sresid=TRUE, format='SPSS')
# Each cell has an expected value > 5.  The p-value is < .05, so the term does make a difference in the loan status.
# Post Hocs: If so, how?
# People with a 36 month loan were more likely to fully pay it off than being current, or having it charged off.
# People with a 60 month loan were more likely to either be current with it or have it charged off than fully paying it off.

# Part 2: How has the ability to own a home changed after 2009?
str(loans)
loans$DateR = as.Date(paste(loans$Date), '%m/%d/%Y')
loans2 = separate(loans, DateR, c('Year', 'Month', 'Day'), sep='-') 

loans2$YearR = NA
loans2$YearR[loans2$Year <= 2009] <- 0
loans2$YearR[loans2$Year > 2009] <- 1

loans2$RentvOwn = NA
loans2$RentvOwn[loans2$home_ownership == 'RENT'] <- 0
loans2$RentvOwn[loans2$home_ownership == 'OWN'] <- 1

CrossTable(loans2$RentvOwn, loans2$YearR, fisher=TRUE, chisq=TRUE, mcnemar=TRUE, expected=TRUE, sresid=TRUE, format='SPSS')
# Each cell has an expected value > 5.  The p-value is < .05, there is a difference in the ability to own a home after 2009.
# Post Hoc analysis
# None of the residuals are > 2, meaning this is not significant enough.  The ability to own a home hasn't changed too much after 2009, more people are renting.

# Part 3: Does it seem likely that this data came from the larger population of America?
loans %>% group_by(loan_status) %>% summarize(count=n())

observed = c(18173, 3282, 502)
expected = c(.15, .10, .75)
chisq.test(x = observed, p = expected)

# The p-value is < .05, this data does not appear to come from the larger population of America.