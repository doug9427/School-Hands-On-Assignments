## Load in libraries
library("mvnormtest")
library("car")

## Data Wrangling
str(heartAttacks)
heartAttacks$trestbps = as.numeric(heartAttacks$trestbps)
heartAttacks$chol = as.numeric(heartAttacks$chol)
heartAttacks$sex = as.factor(heartAttacks$sex)

## Subset the dependent variables
keeps = c('trestbps', 'chol')
heartAttacks1 = heartAttacks[keeps]
# No need to subset the rows, as there are only 303 rows

# Matrix
heartattacks = as.matrix(heartAttacks1)

## Sample size has been met, there is more than enough cases.

## Multivariate Normality
mshapiro.test(t(heartattacks))
# Did not pass the test, the p-value is significant at < .05.  Continuing on for learning purposes

## Homogeneity of variance
leveneTest(trestbps ~ sex, data=heartAttacks)
leveneTest(chol ~ sex, data=heartAttacks)
# The test failed for cholesterol with it being significant with a p-value < .05
# The test passed for resting blood pressure with it not being significant, with the p-value > .05
# Continuing on for learning purposes

## Absence of Multicollinearity
cor.test(heartAttacks$trestbps, heartAttacks$chol, method='pearson', use='complete.orbs')
# Assumption has been met. The correlation is .12 proving there is an absence of mulitcollinearity

## Analysis
MANOVA = manova(cbind(trestbps, chol) ~ sex, data = heartAttacks)
summary(MANOVA)
# There is a significant difference in resting blood pressure and cholesterol by the sex of the individual

## Post Hocs
summary.aov(MANOVA, test = 'wilks')
# There isn't any significance between sex and resting blood pressure.  There is however, a significance between sex and cholesterol.