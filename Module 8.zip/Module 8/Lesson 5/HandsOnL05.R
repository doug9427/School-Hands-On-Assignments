library('rcompanion')
library('fastR2')
library('car')
library('dplyr')
library('IDPmisc')

# Data Wrangling
honey1 = NaRV.omit(honey)
keeps = c('state', 'numcol', 'totalprod', 'year')
honey2 = honey1[keeps]
honey2$year = as.factor(honey2$year)

# Checking for normality
plotNormalHistogram(honey2$totalprod)
# Positively skewed; using square root transformation
honey2$totalprodSQRT = sqrt(honey2$totalprod)
plotNormalHistogram(honey2$totalprodSQRT)
# Still not good enough, continuing on with a log transformation
honey2$totalprodLOG = log(honey2$totalprod)
plotNormalHistogram(honey2$totalprodLOG)
# Much closer to a normal distribution with a log transformation

# Homogeneity of variance test
leveneTest(totalprodLOG ~ year, data=honey2)
# This has passed the test, no need for any correction

# Analysis
RManova = aov(totalprodLOG~year+Error(state), honey2)
summary(RManova)
# The p-value is > .001, there is not a significant change in total production of honey over the years