# Load in necessary libraries
library(rcompanion)
library(IDPmisc)
# Checking the normality of the data
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.Fall)
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.Fall)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.per.year)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.year)
plotNormalHistogram(Seattle_ParksnRec$increase.decrease.of.prior.year)
plotNormalHistogram(Seattle_ParksnRec$Average...people.per.trip)
# Most of these appear positive.  The last two look fairly normal but slightly skewed

# Transforming the positively skewed variables - square root
Seattle_ParksnRec$X..of.trips.FallSQRT = sqrt(Seattle_ParksnRec$X..of.trips.Fall)
Seattle_ParksnRec$X..of.participants.FallSQRT = sqrt(Seattle_ParksnRec$X..of.participants.Fall)
Seattle_ParksnRec$X..of.trips.per.yearSQRT = sqrt(Seattle_ParksnRec$X..of.trips.per.year)
Seattle_ParksnRec$X..participants.per.yearSQRT = sqrt(Seattle_ParksnRec$X..participants.per.year)

# Checking the square root transformation results
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.FallSQRT)
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.FallSQRT)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.per.yearSQRT)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.yearSQRT)
# This seemed to help the  Fall participants and the per year participants variables. Not the two other variables very much though

# Transforming the positively skewed variables - log
Seattle_ParksnRec$X..of.trips.FallLog = log(Seattle_ParksnRec$X..of.trips.Fall)
Seattle_ParksnRec$X..of.participants.FallLog = log(Seattle_ParksnRec$X..of.participants.Fall)
Seattle_ParksnRec$X..of.trips.per.yearLog = log(Seattle_ParksnRec$X..of.trips.per.year)
Seattle_ParksnRec$X..participants.per.yearLog = log(Seattle_ParksnRec$X..participants.per.year)

# Checking the log transformation results
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.FallLog)
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.FallLog)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.per.yearLog)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.yearLog)
# Compared to the square root transformations, the log transformations are the best fit for each variable

# Transforming the questionable variables
Seattle_ParksnRec$increase.decrease.of.prior.yearSQ = Seattle_ParksnRec$increase.decrease.of.prior.year ^ 2
Seattle_ParksnRec$Average...people.per.tripSQRT = sqrt(Seattle_ParksnRec$Average...people.per.trip)

# Checking the transformation results
plotNormalHistogram(Seattle_ParksnRec$increase.decrease.of.prior.yearSQ)
plotNormalHistogram(Seattle_ParksnRec$Average...people.per.tripSQRT)
# After squaring the increase/decrease variable it shifted drastically. The increase/decrease variable is normal as it is, there is no need to transform it.  
# The Average people variable does look better but let's try a log transformation for comparison

Seattle_ParksnRec$Average...people.per.tripLog = log(Seattle_ParksnRec$Average...people.per.trip)
plotNormalHistogram(Seattle_ParksnRec$Average...people.per.tripLog)
# A log transformation is the best fit option

# Tukey' Ladder of Power Transformation
Seattle_ParksnRec$X..of.trips.FallTUK = transformTukey(Seattle_ParksnRec$X..of.trips.Fall, plotit = FALSE)
Seattle_ParksnRec$X..of.participants.FallTUK = transformTukey(Seattle_ParksnRec$X..of.participants.Fall, plotit = FALSE)
Seattle_ParksnRec$X..of.trips.per.yearTUK = transformTukey(Seattle_ParksnRec$X..of.trips.per.year, plotit = FALSE)
Seattle_ParksnRec$X..participants.per.yearTUK = transformTukey(Seattle_ParksnRec$X..participants.per.year, plotit = FALSE)
Seattle_ParksnRec$increase.decrease.of.prior.yearTUK = transformTukey(Seattle_ParksnRec$increase.decrease.of.prior.year, plotit = FALSE)
Seattle_ParksnRec$Average...people.per.tripTUK = transformTukey(Seattle_ParksnRec$Average...people.per.trip, plotit = FALSE)

# Plotting the Tukey transformation
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.FallTUK)
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.FallTUK)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.per.yearTUK)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.yearTUK)
plotNormalHistogram(Seattle_ParksnRec$increase.decrease.of.prior.yearTUK)
plotNormalHistogram(Seattle_ParksnRec$Average...people.per.tripTUK)