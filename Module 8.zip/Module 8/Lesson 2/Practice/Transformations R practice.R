# eliminate any missing or infinite values
cruiseship = NaRV.omit(cruise_ship)
# Checking for normality
plotNormalDensity(cruise_ship$YearBlt) # negative kurtosis leptokurtic
# Transforming the data
cruiseYearBlt = cruiseship$YearBlt ^ 2
plotNormalHistogram(cruiseYearBlt)
