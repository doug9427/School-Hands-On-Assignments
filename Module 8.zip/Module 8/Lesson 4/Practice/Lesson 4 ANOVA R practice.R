library('dplyr')
library('rcompanion')
library('car')

# Data wrangling

plotNormalHistogram(YouTubeChannels$Video.views)
# Positively skewed

# Square Root transformation
YouTubeChannels$Video.viewsSQRT = sqrt(YouTubeChannels$Video.views)
plotNormalHistogram(YouTubeChannels$Video.viewsSQRT)
# slightly better but not enough

# Log transformation
YouTubeChannels$Video.viewsLog = log(YouTubeChannels$Video.views)
plotNormalHistogram(YouTubeChannels$Video.viewsLog)
# Sticking with the square root transformation

# Testing for homogeneity of Variance
bartlett.test(Video.viewsSQRT ~ Grade, data=YouTubeChannels)
# p-value is < .05, moving on to fligner's test
fligner.test(Video.viewsSQRT ~ Grade, data=YouTubeChannels)
# With the p-value still < .05, assumption of homogeneity of variance has been violated

# Unequal variance
ANOVA1 = lm(Video.viewsSQRT ~ Grade, data=YouTubeChannels)
Anova(ANOVA1, Type='II', white.adjust=TRUE)

# Unequal variance post hocs
pairwise.t.test(YouTubeChannels$Video.viewsSQRT, YouTubeChannels$Grade, p.adjust='bonferroni', pool.sd = FALSE)

YouTubeChannelsMeans <- YouTubeChannels %>% group_by(Grade) %>% summarize(Mean = mean(Video.views))