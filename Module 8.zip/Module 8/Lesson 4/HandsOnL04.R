# Loading in the necessary libraries
library('dplyr')
library('rcompanion')
library('car')
library('IDPmisc')

# Data Wrangling
avocados = na.omit(avocados %>% filter(region %in% c('Albany', 'Houston', 'Seattle')))
avocado = NaRV.omit(avocados)

# Test assumptions
plotNormalHistogram(avocados$AveragePrice)

# Transforming the average price with square root & log
avocados$AveragePriceSQRT = sqrt(avocados$AveragePrice)
plotNormalHistogram(avocados$AveragePriceSQRT)
avocados$AveragePriceLOG = log(avocados$AveragePrice)
plotNormalHistogram(avocados$AveragePriceLOG)
# Log transformation has the best result

# Testing for homogeneity of variance
bartlett.test(AveragePriceLOG ~ region, data=avocados)
# Did not meet the assumption of homogeneity of variance

# Perform the test with unequal variance
ANOVA = lm(AveragePriceLOG ~ region, data=avocados)
Anova(ANOVA, Type='II', white.adjust=TRUE)

# Post Hocs analysis
pairwise.t.test(avocados$AveragePriceLOG, avocados$region, p.adjust='bonferroni', pool.sd=FALSE)

# Checking means and conclusions
avocadosMeans = avocados %>% group_by(region) %>% summarize(Mean = mean(AveragePrice))
avocadosMeans
# All regions do differ significantly from each other withe the average price; however, Albany and Seattle have slightly higher average prices than Houston.