library('IDPmisc')
library('rcompanion')
library('car')
library('dplyr')

## Data Wrangling
keeps = c('�..country', 'year', 'sex', 'age', 'suicides.100k.pop', 'generation')
suicide1 = suicide[keeps]
str(suicides)

## Checking for normality
plotNormalHistogram(suicide1$suicides.100k.pop)
# Square root transformation
suicide1$suicides.100k.popSQRT = sqrt(suicide1$suicides.100k.pop)
plotNormalHistogram(suicide1$suicides.100k.popSQRT)
# Log transformation
suicide1$suicides.100k.popLOG = log(suicide1$suicides.100k.pop)
suicides = NaRV.omit(suicide1)
plotNormalHistogram(suicides$suicides.100k.popLOG)
# Much closer to a normal distribution

## Homogeneity of variance test
leveneTest(suicides.100k.popLOG ~ generation, data=suicides)
# Assumption has succeeded, as the test was not significant

## Analysis
RManova = aov(suicides.100k.popLOG~(generation*year)+Error(�..country/(year)), suicides)
summary(RManova)
# There does not seem to be any significance here.  Going off the three stars, both p-values are > 0.
# If however we compare this to an alpha of .05, there is very much a significant influence between the generations and suicide. Also an interaction between the year and the generations.

## Post Hocs
pairwise.t.test(suicides$suicides.100k.popLOG, suicides$generation, p.adjust='bonferroni')
# Suicide rates are different between the generations.

## Means and Conclusion
suicideMeans = suicides %>% group_by(generation, year) %>% summarize(Mean=mean(suicides.100k.pop))
# Suicide rates are higher with the G.I and Silent generations. Gen Z does have the lowest suicide rates and Millenials also have a low suicide rate but it has increase steadily over the years. Boomers and Gen X are fairly steady for suicide rates over the years.
suicideMeans %>% as_tibble() %>% print(n=Inf)