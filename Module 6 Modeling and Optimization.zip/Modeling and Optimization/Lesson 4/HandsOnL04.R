#Backward Selection
FitAll1 <- lm(IQ ~ ., data = IQ)

summary(FitAll1)

step(FitAll1, direction = 'backward')

#Create another model for only selected variables and compare their results
fitsome <- lm(IQ ~ Test1 + Test2 + Test4, data = IQ)
summary(fitsome)

#Backward Selection
FitAll = lm(Y ~ ., data = stepwiseRegression)
summary(FitAll)

step(FitAll, direction = 'backward', scope = formula(FitAll))

#Forward Selection
fitstart = lm(Y ~ 1, data = stepwiseRegression)
summary(fitstart)

step(fitstart, direction = 'forward', scope = (formula(FitAll)))

#StepWise 
step(fitstart, direction = 'both', scope = formula(FitAll))

fitsome <- lm(formula = Y ~ X2 + X4 + X6 + X10 + X11 + X12, data = stepwiseRegression)
summary(fitsome)