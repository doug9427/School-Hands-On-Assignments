# Pair One:

# Scatterplot
scatter1 <- ggplot(nonlinear, aes(x = X1, y = Y1)) + geom_point()
scatter1

# Best-fit quadratic line
quadPlot1 <- ggplot(nonlinear, aes(x = X1, y = Y1)) + geom_point() + stat_smooth(method = 'lm', formula = y ~ x + I(x^2), size = 1)
quadPlot1

# Testing a quadratic function model
X1sq <- nonlinear$X1^2
quadModel1 <- lm(nonlinear$Y1~nonlinear$X1+X1sq)
summary(quadModel1)

# Testing an exponential function model
exModel1 <- lm(log(nonlinear$Y1)~nonlinear$X1)
summary(exModel1)

# It looks like either model could fit for these variables

# Pair Two:

# Scatterplot
scatter2 <- ggplot(nonlinear, aes(x = X2, y = Y2)) + geom_point()
scatter2

# Best-fit quadratic line
quadPlot2 <- ggplot(nonlinear, aes(x = X2, y = Y2)) + geom_point() + stat_smooth(method = 'lm', formula = y ~ x + I(x^2), size = 1)
quadPlot2

# Testing a quadratic function model
X2sq <- nonlinear$X2^2
quadModel2 <- lm(nonlinear$Y2~nonlinear$X2+X2sq)
summary(quadModel2)

# Testing an exponential function model
exModel2 <- lm(log(nonlinear$Y2)~nonlinear$X2)
summary(exModel2)

# It looks like either model could fit for these variables