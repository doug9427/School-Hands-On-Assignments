e.times <- faithful$eruptions
short <- e.times[e.times < 3]
long <- e.times[e.times > 3]
length(short)
length(long)
mean(short)
mean(long)
sd(short)
sd(long)
