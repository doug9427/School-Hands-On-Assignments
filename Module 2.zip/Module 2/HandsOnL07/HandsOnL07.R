first25 <- nhtemp[1:25]
last25 <- nhtemp[36:60]
t_dep <- t.test(first25, last25, paired = TRUE)
df <- data.frame(first25, last25)
bp <- melt(df, measure.vars = c("first25", "last25"))
tbp <- ggplot(bp) + geom_boxplot(aes(x = variable, y = value)) + xlab("Year") + ylab("Tempature")
