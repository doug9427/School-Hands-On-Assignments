hp <- ggplot(mtcars, aes(x = hp, y = qsec))
hp + geom_point() + geom_smooth(method=lm)
hp_matrix <- lm(qsec ~ hp, mtcars)
summary(hp_matrix)

wt <- ggplot(mtcars, aes(x = wt, y = qsec))
wt + geom_point() + geom_smooth(method=lm)
wt_matrix <- lm(qsec ~ wt, mtcars)
summary(wt_matrix)
