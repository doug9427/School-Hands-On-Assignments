five_countries <- gapminder %>%
  filter(country %in% c("Eritrea", "France", "Lebanon", "Namibia", "Niger")) %>%
  select(country, year, lifeExp, gdpPercap)
first.graph <- ggplot(five_countries) + geom_line(aes(x = year, y = gdpPercap, color = country)) + xlab("Year") + ylab("Per Capita GDP") + ggtitle("GDP in Five Countries")
second.graph <- ggplot(five_countries, aes(x = year, y = lifeExp, color = country)) + geom_point() + geom_path() + xlab("Year") + ylab("Life Expectancy") + ggtitle("Life Expectancy in Five Countries")
life <- gapminder %>% group_by(year) %>% summarise(life.med = median(lifeExp))
