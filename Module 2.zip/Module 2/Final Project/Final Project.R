# Create a boxplox for packpc.
one.gr <- ggplot(Cigarette) + geom_boxplot(aes(x = state, y = packpc)) + xlab("State") + ylab("Packs per Capita") + ggtitle("Number of Packs per Capita by State")
# Create a tibble to arrange.
one.re <- Cigarette %>% group_by(state) %>% summarize(pack.med = median(packpc))
# Highest? Lowest?
one.bot <- arrange(one.re, pack.med)
one.top<- arrange(one.re, desc(pack.med))
# Find the Median for packpc of all states from '85 to '95.
two.re <- Cigarette %>% group_by(year) %>% summarize(pack.med = median(packpc))
# Plot the above code and analysis the graph. What happened?
two.gr <- ggplot(two.re) + geom_line(aes(x = year, y = pack.med)) + xlab("Year") + ylab("Median Packs per Capita") + ggtitle("Trend of the Median Number of Packs per Capita from 1985 to 1995")
# Create a scatter plot avgprs vs packpc. How are they correlated?
three.gr <- ggplot(Cigarette, aes(x = avgprs, y = packpc)) + geom_point() + xlab("Price per Packs") + ylab("Packs per Capita") + ggtitle("Price per Packs versus Packs per Capita")
# Add color to the years from the code above. Relationship changed over time?
four.gr <- ggplot(Cigarette, aes(x = avgprs, y = packpc, color = year)) + geom_point() + xlab("Price per Packs") + ylab("Packs per Capita") + ggtitle("Price per Packs versus Packs per Capita")
# Do a linear regression. Variance explanation
five.re <- lm(packpc ~ avgprs, Cigarette) %>% summary()
# Adjust for inflation.
Cigarette.infl <- mutate(Cigarette, inflrt = avgprs / cpi)
# Create scatter plot with adjusted price.
six.gr <- ggplot(Cigarette.infl, aes(x = inflrt, y = packpc, color = year)) + geom_point() + xlab("Inflation Rates") + ylab("Packs per Capita") + ggtitle("Price per Packs versus Packs per Capita")
# Do a linear regression with adjusted price.
six.re <- lm(packpc ~ inflrt, Cigarette.infl) %>% summary()
# Create data frame for year 1985.
df.85 <- Cigarette %>% filter(year==1985)
#Create data frame for year 1995.
df.95 <- filter(Cigarette, year==1995)
# Put both data frames into two separate vectors.
vec.95 <- select(df.95, packpc)
vec.85 <- select(df.85, packpc)
# Do a dependent t.test. (Don't forget to specify each column with $)
vec.test <-  t.test(vec.95$packpc, vec.85$packpc, paired = TRUE)
#No further questions.