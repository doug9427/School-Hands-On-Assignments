ggplot(mtcars, aes(x = cyl, y = mpg)) + geom_boxplot(aes(group=cyl))
mtcars %>% group_by(cyl) %>% summarize(count = n())
