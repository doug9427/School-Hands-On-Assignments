rr = data.frame(rivers)
r <- ggplot(rr, aes(x = rivers))
r + geom_histogram(binwidth = 150) +
  ggtitle("Histogram of River Lengths") + xlab("Length in Miles")
d <- ggplot(rr, aes(x ="", y = rivers))
d + geom_boxplot() + xlab("") + ylab("Length in MIles")
ggplot(rr, aes(sample = rivers)) + geom_qq()
summary(rivers)