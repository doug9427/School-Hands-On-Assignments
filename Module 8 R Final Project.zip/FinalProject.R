### Load in Libraries
library('gmodels')
library('dplyr')
library('rcompanion')
library('car')
library('tidyr')
library('IDPmisc')

### Scenario 1: One-proportional z test
prop.test(x = 28, n = 94, p = .16, alternative = 'two.sided', correct=FALSE)
# The p-value is < .05, meaning the incidence of fraud is more than 16%.

### Scenario 2: Independent Chi-Square
antiseptics.expanded = antiseptics[rep(row.names(antiseptics), antiseptics$Number.of.applications), 1:2]
CrossTable(antiseptics.expanded$Clinic, antiseptics.expanded$Antiseptic.Type, fisher=TRUE, chisq=TRUE, expected=TRUE, sresid=TRUE, format='SPSS')
# The expected values in each cell is > 5, passing the assumption of expected frequencies
# The p-value is > .05, there is no significant difference between the antiseptic type usage and the clinics

### Scenario 3: One-way Anova
# Data Wrangling
savings.reformat1 = gather(savings, key="Group", value="Price")
savings.reformat = NaRV.omit(savings.reformat1)

## Normality test
plotNormalHistogram(savings.reformat$Price)
# Square root transformation
savings.reformat$PriceSQRT = sqrt(savings.reformat$Price)
plotNormalHistogram(savings.reformat$PriceSQRT)
# The square root transformation shifted the data too much to the left.
# Sticking with no transformation

## Homogeneity of Variance
bartlett.test(Price ~ Group, data=savings.reformat)
# The assumption has failed, the p-value is < .05

## Unequal Variance, Welch's One-way Test
ANOVA = lm(Price ~ Group, data=savings.reformat)
Anova(ANOVA, Type='II', white.adjust=TRUE)
# The p-value is < .05, so there is some significant difference between the groups

## Post Hocs, with unequal variance
pairwise.t.test(savings.reformat$Price, savings.reformat$Group, p.adjust='bonferroni', pool.sd = FALSE)
# There is significance in the comparisons between the four groups.

## Mean comparisons and conclusion
savings.reformatMeans = savings.reformat %>% group_by(Group) %>% summarize(Mean = mean(Price))
savings.reformatMeans
# Group A has more savings than the rest, while group C has the least amount in savings by a noticeable margin.

### Scenario 4: Two-proportional z test
prop.test(x = c(374, 171), n = c(503, 245), alternative = 'two.sided')
# The p-value is > .05, meaning there is no significant difference in the proportions of favored in either group