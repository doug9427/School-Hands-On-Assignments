trials = 10000
alpha = 9
beta = 1
sampleA <- rbeta(trials, 27+alpha, 39 + beta)
sampleB <- rbeta(trials, 10+alpha, 45 + beta)
Bsuperior <- sum(sampleB > sampleA) / trials
Bsuperior

