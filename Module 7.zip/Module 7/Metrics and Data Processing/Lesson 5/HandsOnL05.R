# subset the data
area = studentSurvey[, 31:42]

# Omit Na
area2 = NaRV.omit(area)

# Checking for absence of multicollinearity
areaMatrix = cor(area2)
View(round(areaMatrix, 2))

# Bartlett Test
cortest.bartlett(area2)

# checking the determinants
det(areaMatrix)
# since test was greater than .00001 continue on to model fit

# number of factors
areaModel = principal(area2, nfactors = 12, rotate = 'none')

# Scree Plot
plot(areaModel$values, type='b')
# There is only one factor that is greater than 1

# Examine residuals to determine model fit
areaModel2 = principal(area2, nfactors = 1, rotate = 'none')
residuals = factor.residuals(areaMatrix, areaModel2$loadings)
residuals = as.matrix(residuals[upper.tri(residuals)])
largeResid = abs(residuals) > .05
sum(largeResid)
sum(largeResid/nrow(residuals))
# 45% of the residuals are large. One factor is a good model fit.

# Reliability
alpha(area2)
# raw_alpha is .92. Greater than .8, so good inter-rater reliability
# Dropping any item will not increase the reliability
# The numbers in the r.drop column are greater than .3, so good inter-item reliability
# The response frequencies does not seem to be decently spread out.
# There are more in columns 4 and 5.
