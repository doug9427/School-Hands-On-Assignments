# Create a model
mylogit <- glm(Gold ~ �..Antimony, data=minerals, family='binomial')

# Predictions
probabilities <- predict(mylogit, type = 'response')
minerals$Predicted <- ifelse(probabilities > .5, "pos", "neg")

# Recode predicted variable
minerals$PredictedR <- NA
minerals$PredictedR[minerals$Predicted=='pos'] <- 1
minerals$PredictedR[minerals$Predicted=='neg'] <- 0

# Convert Variables to Factors
minerals$PredictedR <- as.factor(minerals$PredictedR)
minerals$Gold <- as.factor(minerals$Gold)

# Create a confusion matrix
conf_mat <- caret::confusionMatrix(minerals$PredictedR, minerals$Gold)
conf_mat # Does not meet minimum sample size R:0;P:1 less than 5

# Numeric variables
minerals1 <- minerals %>%
dplyr::select_if(is.numeric)

# Rename column
predictors <- colnames(minerals1)

# Math
minerals1 <- minerals1 %>%
mutate(logit=log(probabilities/(1-probabilities))) %>%
gather(key= 'predictors', value='predictor.value', -logit)

# Graphing time
ggplot(minerals1, aes(logit, predictor.value)) +
geom_point(size=.5, alpha=.5)+
geom_smooth(method= 'loess')+
theme_bw()+
facet_wrap(~predictors, scales='free_y')

# Graphing Errors
plot(mylogit$residuals)

# Durbin-Watson Test
dwtest(mylogit, alternative = "two.side") 
# Not statistically significant. Met assumption of independent errors

# Screening Outliers
infl <- influence.measures(mylogit)
summary(infl)
# dfb.1 and dffit are less than 1. Hat has data less than .3
# No outliers that need to be removed

# Summary
summary(mylogit)
# log odds of 1,76 increase of findin gold