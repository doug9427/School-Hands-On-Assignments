new_text = 'Python was conceived in the late 1990s by Guido van Rossum'

with open('updating.txt', 'w') as file:
    file.write(new_text)
    print('\nFile Now Closed?:', file.closed)
print('File Now Closed?:', file.closed)

with open('updating.txt', 'r+') as file:
    new_text = file.read()
    print('\nString:', new_text)
    print('\nPosition In File Now:', file.tell())
    position = file.seek(33)
    print('Position In File Now:', file.tell())
    file.write('1980s')
    file.seek(0)
    new_text = file.read()
    print('\nString:', new_text)