name = "What is your name?"
print(name)

name = 'My name is "Billy."'
print(name)

age = "How old are you?"
print(age)

age = 30
print(age)

# months = "How many months is that?"
# print(months)

# months = 360
# print(months)

string = "This is fun!"
integer = 37
float = 3.7
print(string)
print(integer)
print(float)