# Part 1
class Stadium:
    """This class represents a stadium"""

    def __init__(self, name, city_state, capacity, sport, seating):
        """Initializer"""
        self.name = name
        self.city_state = city_state
        self.capacity = capacity
        self.sport = sport      # Part 2
        self.seating = seating      # Part 2
    
    def describe_stadium(self):
        """Description of the stadium"""
        print("The", self.name, "is located in", self.city_state, "and holds", self.capacity, "fans.")
    
    def sport_played(self):     # Part 2
        """Sport played"""
        print("The following sport is mainly played in this stadium:", self.sport)

    def seats_available(self):      # Part 2
        """Seating"""
        print("There are", self.seating, "seats still available for tonight's game.")

stadium1 = Stadium("Mercede Benz Arena", "Atlanta, GA", "70,000", "Football", "15000")

# Part 1
stadium1.describe_stadium()
# Part 2
stadium1.sport_played()
stadium1.seats_available()