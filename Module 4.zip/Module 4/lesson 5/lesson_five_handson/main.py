# Part 1
def sum_function(x, y, z):
    return x + y + z
def product_function(x, y, z):
    return x * y * z
def average_function(x, y, z):
    return (x + y + z) / 3

print(sum_function(1, 2, 3))
print(product_function(1, 2, 3))
print(average_function(1, 2, 3))

print('---')

# Part 2
add_numbers = lambda a, b, c: a + b + c
multiply_numbers = lambda a, b, c: a * b * c
average_numbers = lambda a, b, c: (a + b + c) / 3
print(add_numbers(1,3,5,))
print(multiply_numbers(1,3,5))
print(average_numbers(1,3,5))

print('---')

# Part 3
list_one = [4, 6, 88, 24]
list_two = [17, 34, 9, 5]
list_three = [63, 20, 98, 4]

average_maker = lambda a, b, c: (a + b + c)/ 3
map_results = map(average_maker, list_one, list_two, list_three)
result = list(map_results)

print(result)