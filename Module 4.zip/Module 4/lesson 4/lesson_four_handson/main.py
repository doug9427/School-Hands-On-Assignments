# Part 1
Meiku = {'Type' : 'Dog',
      'Color' : 'White and Brown',
       'Nickname' : 'Meikus',
       'Owner' : 'Douglas'}
Mittens = {'Type' : 'Cat',
        'Color' : 'Black and White',
        'Nickname' : 'Pain',
        'Owner' : 'Bailey'}

for key, value in Meiku.items():
    print(key + ":", value)
for key, value in Mittens.items():
    print(key + ':', value)

print('---')
# Part 2
england = {'Capital': 'London'}
france = {'Capital': 'Paris'}
belgium = {'Capital': 'Brussels'}

england['Population'] = '53.01 million'
england['Interesting Fact'] = 'There is an annual cheese rolling competition'
england['Language'] = 'English'

france['Population'] = '66.9 million'
france['Interesting Fact'] = 'It is illegal to throw out food'
france['Language'] = 'French'

belgium['Population'] = '11.35 million'
belgium['Interesting Fact'] = 'Audrey Hepburn was born in Brussels'
belgium['Language'] = 'Dutch'

for key, value in england.items():
    print(key + ':', value)
for key, value in france.items():
    print(key + ':', value)
for key, value in belgium.items():
    print(key + ':', value)

print('---')
# Part 3
pizza_order = {"Customer's Name" : 'Bailey',
               'Size' : 'large,',
               'Crust' : 'hand-tossed',
               'Toppings' : 'cheese, ' 'pepperoni, ' 'pineapple'}
print("Thank you for your order,", pizza_order.get("Customer's Name"))
print("You have ordered a", pizza_order.get('Size'), pizza_order.get('Crust'), "pizza with the following toppings:", pizza_order.get('Toppings'))