age = 18
car = False
mom_car = True
outcome = ""

if age >= 18 and car:
    outcome ='I can go and see an R-rated movie.'
elif age >= 13 and mom_car:
    outcome = 'Mom can take me to see a PG13-rated movie.'
else:
    outcome = "I'm stuck at home today"

print(outcome)