everyone = ['Sally', 'Billy', 'Mary', 'Bob']
looking_for = 'Mary'

for person in everyone:
    if person != looking_for:
        continue
    print("Found " + looking_for + "!")
