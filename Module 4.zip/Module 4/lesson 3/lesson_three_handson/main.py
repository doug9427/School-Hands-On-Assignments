# Part 1
list_of_names = ['Kurt', 'David', 'Katherine']

for name in list_of_names:
    print("Where is " + name + " today?")

# Part 2
my_favorite_cars = ['Lincoln', 'Spark', 'Cruze']
my_favorite_flowers = ['Lavender', 'Lily', 'Rose', 'White Rose']
my_favorite_animals = ['Dog', 'Furret', 'Weasel', 'Sabel', 'Owl']

my_favorite_things = my_favorite_cars + my_favorite_flowers + my_favorite_animals

for thing in my_favorite_things:
    if len(thing) % 2 == 0:
        print(thing)

# Part 3
number_range = list(range(1,21))

for number in number_range:
    if number % 3 == 0 and number % 5 == 0:
        print('ZigZap')
    elif number % 3 == 0:
        print('Zip')
    elif number % 5 == 0:
        print('Zap')
    else:
        print(number)